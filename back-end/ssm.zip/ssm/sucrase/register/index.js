require("../dist/register").registerAll();

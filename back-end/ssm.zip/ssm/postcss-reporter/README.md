# postcss-reporter

A PostCSS plugin to `console.log()` the messages (warnings, etc.) registered by other PostCSS plugins.

---

**SEEKING A NEW MAINTAINER!** Interested in contributing to the ecosystem of PostCSS and Stylelint? Please open an issue if you'd like to take over maintenance of this package.

---

## Docs
Read full docs **[here](https://github.com/postcss/postcss-reporter#readme)**.
